# Шаблонизатор Pug и препоцессор Stylus на Webpack

Репозиторий был создан для решения двух последних лабороторных работ с использованием Webpack

## Давайте начнём

Снчала склонируйте репозиторий:

```console
git clone https://github.com/Kisa6996/template_pug.git
```

После этого установите пакеты node_modules:
```console
npm install
```

Далее запустите свой проект:
```console
npm run server
```
